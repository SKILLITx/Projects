import { Summary } from "@/lib/api";

export default function SummaryBar({ summary }: { summary: Summary }) {
  const items = [
    { label: "Accounts Scored", value: summary.total_dealers, color: "text-white" },
    { label: "High Risk", value: summary.red_count, color: "text-red" },
    { label: "Moderate", value: summary.amber_count, color: "text-amber" },
    { label: "Reliable", value: summary.green_count, color: "text-green" },
  ];

  return (
    <div className="bg-navy px-6 md:px-10 py-6">
      <div className="max-w-6xl mx-auto flex flex-wrap items-end justify-between gap-6">
        <div className="flex flex-wrap gap-x-10 gap-y-4">
          {items.map((it) => (
            <div key={it.label}>
              <p className={`font-display text-3xl font-medium ${it.color}`}>{it.value}</p>
              <p className="font-mono text-[10px] uppercase tracking-wide text-ice/50 mt-1">
                {it.label}
              </p>
            </div>
          ))}
        </div>
        {summary.salesman_favorite_red_count > 0 && (
          <div className="rounded-sm border border-red/40 bg-red/10 px-4 py-2.5">
            <p className="font-body text-[13px] text-white">
              <span className="font-semibold">{summary.salesman_favorite_red_count}</span> trusted{" "}
              {summary.salesman_favorite_red_count === 1 ? "account" : "accounts"} flagged high risk
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
