"use client";

import { useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";

interface UploadViewProps {
  onSubmit: (dealers: File, salesmen: File, transactions: File) => void;
  loading: boolean;
  error: string | null;
}

interface SlotProps {
  label: string;
  hint: string;
  file: File | null;
  onSelect: (f: File) => void;
}

function FileSlot({ label, hint, file, onSelect }: SlotProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);

  return (
    <div
      onDragOver={(e) => {
        e.preventDefault();
        setDragging(true);
      }}
      onDragLeave={() => setDragging(false)}
      onDrop={(e) => {
        e.preventDefault();
        setDragging(false);
        const f = e.dataTransfer.files?.[0];
        if (f) onSelect(f);
      }}
      onClick={() => inputRef.current?.click()}
      className={`group cursor-pointer rounded-sm border px-5 py-4 transition-colors ${
        dragging
          ? "border-navy bg-ice/40"
          : file
          ? "border-navy/40 bg-navy/[0.03]"
          : "border-parchment-line bg-white/40 hover:border-navy/30"
      }`}
    >
      <input
        ref={inputRef}
        type="file"
        accept=".csv"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) onSelect(f);
        }}
      />
      <div className="flex items-center justify-between gap-4">
        <div>
          <p className="font-body text-[13px] font-medium tracking-wide text-ink">{label}</p>
          <p className="font-mono text-[11px] text-grey mt-0.5">{hint}</p>
        </div>
        <div className="shrink-0">
          {file ? (
            <span className="font-mono text-[11px] text-navy">{file.name}</span>
          ) : (
            <span className="font-mono text-[11px] text-grey/70 group-hover:text-navy transition-colors">
              choose file
            </span>
          )}
        </div>
      </div>
    </div>
  );
}

export default function UploadView({ onSubmit, loading, error }: UploadViewProps) {
  const [dealers, setDealers] = useState<File | null>(null);
  const [salesmen, setSalesmen] = useState<File | null>(null);
  const [transactions, setTransactions] = useState<File | null>(null);

  const ready = dealers && salesmen && transactions;

  return (
    <div className="relative min-h-screen bg-navy overflow-hidden flex items-center justify-center px-6">
      {/* Signature: faint ruled ledger lines receding into the navy field */}
      <div
        className="absolute inset-0 opacity-[0.07]"
        style={{
          backgroundImage:
            "repeating-linear-gradient(to bottom, transparent, transparent 38px, #CADCFC 38px, #CADCFC 39px)",
        }}
      />
      <div className="absolute -right-32 -top-32 w-[520px] h-[520px] rounded-full bg-ice/[0.06] blur-3xl" />

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className="relative z-10 w-full max-w-xl"
      >
        <p className="font-mono text-[11px] tracking-[0.2em] text-ice/60 uppercase mb-3">
          Distributor Credit Risk · The Ledger
        </p>
        <h1 className="font-display text-4xl md:text-5xl font-medium text-white leading-[1.08] mb-4">
          Every account,
          <br />
          <span className="italic text-ice">weighed against its own history.</span>
        </h1>
        <p className="font-body text-[15px] text-ice/70 leading-relaxed mb-10 max-w-md">
          Upload your dealer ledger, salesman roster, and payment history.
          Get back a defensible risk score for every account — including the
          ones your sales team already trusts.
        </p>

        <div className="space-y-3 mb-6">
          <FileSlot
            label="Dealers"
            hint="dealer_id, dealer_name, city, sector, salesman_id, credit_limit_pkr…"
            file={dealers}
            onSelect={setDealers}
          />
          <FileSlot
            label="Salesmen"
            hint="salesman_id, salesman_name…"
            file={salesmen}
            onSelect={setSalesmen}
          />
          <FileSlot
            label="Transactions"
            hint="invoice history — messy exports are fine, we clean them"
            file={transactions}
            onSelect={setTransactions}
          />
        </div>

        <AnimatePresence>
          {error && (
            <motion.p
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="font-body text-[13px] text-red bg-red/10 border border-red/20 rounded-sm px-4 py-3 mb-4"
            >
              {error}
            </motion.p>
          )}
        </AnimatePresence>

        <button
          disabled={!ready || loading}
          onClick={() => ready && onSubmit(dealers, salesmen, transactions)}
          className="w-full rounded-sm bg-ice text-navy-deep font-body font-semibold text-[14px] py-3.5 transition-all disabled:opacity-30 disabled:cursor-not-allowed hover:bg-white active:scale-[0.99]"
        >
          {loading ? (
            <span className="flex items-center justify-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-navy-deep animate-pulse" />
              Reading the ledger…
            </span>
          ) : (
            "Score the portfolio"
          )}
        </button>

        <p className="font-mono text-[10px] text-ice/40 mt-6 text-center">
          Nothing is stored beyond this session. Scores reflect a logistic scorecard, not a black box.
        </p>
      </motion.div>
    </div>
  );
}
